import streamlit as st
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors

# Load data and build the recommendation model
movies_df = pd.read_csv("E:\\movie recommendation\\movies.csv", usecols=['movieId', 'title'], dtype={'movieId': 'int32', 'title': 'str'})
rating_df = pd.read_csv("E:\\movie recommendation\\ratings.csv", usecols=['userId', 'movieId', 'rating'], dtype={'userId': 'int32', 'movieId': 'int32', 'rating': 'float32'})

combine_movie_rating = pd.merge(rating_df, movies_df, on='movieId')

# Calculate the total rating count for each movie
movie_ratingCount = (combine_movie_rating.groupby(by=['title'])['rating'].count().reset_index().rename(columns={'rating': 'totalRatingCount'}))

# Merge the total rating count with the combine_movie_rating DataFrame
combine_movie_rating = pd.merge(combine_movie_rating, movie_ratingCount, on='title')

popularity_threshold = 50
rating_popular_movie = combine_movie_rating.query('totalRatingCount >= @popularity_threshold')

movie_features_df = rating_popular_movie.pivot_table(index='title', columns='userId', values='rating').fillna(0)
movie_features_df_matrix = csr_matrix(movie_features_df.values)

model_knn = NearestNeighbors(metric='cosine', algorithm='brute')
model_knn.fit(movie_features_df_matrix)

# Streamlit UI
st.title("Movie Recommendation System")

st.sidebar.header("Recommend a Movie")
movie_name = st.sidebar.selectbox("Choose a movie:", movies_df['title'])

if st.sidebar.button("Recommend"):
    query_index = movies_df[movies_df['title'] == movie_name].index[0]
    distances, indices = model_knn.kneighbors(movie_features_df.iloc[query_index, :].values.reshape(1, -1), n_neighbors=6)

    st.subheader("Recommended Movies:")
    for i in range(1, len(distances.flatten())):
        recommended_movie = movies_df.iloc[indices.flatten()[i]]['title']
        st.write(f"{i}: {recommended_movie}")

st.sidebar.text("")

st.sidebar.header("About")
st.sidebar.info(
    "This is a movie recommendation system based on user ratings. "
    "Choose a movie, and it will recommend similar movies."
)
